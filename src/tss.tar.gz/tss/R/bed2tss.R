#' Assign a bed data frame to the nearest TSS
#' @param bed A data frame containing chrom, start, end columns
#' @param tss A data frame of TSSs (e.g. hg19.tss)
#' @return The TSSs nearest each bed row
#' @export
bed2tss <- function(bed, tss) {
  # peaks should be a data frame (chrom, start, end)
  # tss_file should be a file with the columns:
  # chrom, position, transcript_id, gene_id, name
  # returns the data frame: peak, nearest_gene, distance

  bed$end <- bed$end - 1
  bed.grange <- makeGRangesFromDataFrame(bed)


  stopifnot(!'start' %in% colnames(tss))
  stopifnot(!'end' %in% colnames(tss))
  tss$start <- tss$pos
  tss$end <- tss$pos

  tss.grange <- makeGRangesFromDataFrame(tss)
  d <- distanceToNearest(bed.grange, tss.grange)
  bed.df <- bed[queryHits(d),]
  tss.df <- tss[subjectHits(d),]
  tss.df$distance <- as.data.frame(d)$distance
  tss.df <- tss.df[,!colnames(tss.df) %in% c('start', 'end')]

  return(tss.df)
}
