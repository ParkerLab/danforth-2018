#' hg19 TSS
#'
#' TSS from hg19
#'
#' @format A data frame with 204940 rows and 5 variables:
#' \describe{
#'   \item{chrom}{chromosome}
#'   \item{pos}{The 1-based position of the TSS}
#'   \item{transcript_id}{ensembl transcript ID}
#'   \item{gene_id}{ensembl gene ID}
#'   \item{gene}{gene name}
#' }
#' @source UCSC MySQL
"hg19.tss"

#' mm9 TSS
#'
#' TSS from mm9
#'
#' @format A data frame with 95883 rows and 5 variables:
#' \describe{
#'   \item{chrom}{chromosome}
#'   \item{pos}{The 1-based position of the TSS}
#'   \item{transcript_id}{ensembl transcript ID}
#'   \item{gene_id}{ensembl gene ID}
#'   \item{gene}{gene name}
#' }
#' @source UCSC MySQL
"mm9.tss"

#' mm10 TSS
#'
#' TSS from mm10
#'
#' @format A data frame with 62613 rows and 4 variables:
#' \describe{
#'   \item{chrom}{chromosome}
#'   \item{pos}{The 1-based position of the TSS}
#'   \item{transcript_id}{ensembl transcript ID}
#'   \item{gene}{gene name}
#' }
#' @source UCSC MySQL (wgEncodeGencodeBasicVM14 table, Dec 5 2017)
"mm10.tss"

#' rn5 TSS
#'
#' TSS from rn5
#'
#' @format A data frame with 30368 rows and 5 variables:
#' \describe{
#'   \item{chrom}{chromosome}
#'   \item{pos}{The 1-based position of the TSS}
#'   \item{transcript_id}{ensembl transcript ID}
#'   \item{gene_id}{ensembl gene ID}
#'   \item{gene}{gene name}
#' }
#' @source UCSC MySQL
"rn5.tss"

#' rn4 TSS
#'
#' TSS from rn4
#'
#' @format A data frame with 37499 rows and 5 variables:
#' \describe{
#'   \item{chrom}{chromosome}
#'   \item{pos}{The 1-based position of the TSS}
#'   \item{transcript_id}{ensembl transcript ID}
#'   \item{gene_id}{ensembl gene ID}
#'   \item{gene}{gene name}
#' }
#' @source UCSC MySQL
"rn4.tss"

#' danforth TSS
#'
#' TSS from danforth
#'
#' @format A data frame with 95883 rows and 5 variables:
#' \describe{
#'   \item{chrom}{chromosome}
#'   \item{pos}{The 1-based position of the TSS}
#'   \item{transcript_id}{ensembl transcript ID}
#'   \item{gene_id}{ensembl gene ID}
#'   \item{gene}{gene name}
#' }
#' @source UCSC MySQL
"danforth.tss"
